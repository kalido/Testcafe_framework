To generate .env file use:

VALID_USERNAME = standard_user
VALID_PASSWORD = secret_sauce
INVALID_USERNAME = st4nd4rd_user
INVALID_PASSWORD = not_secret_sauce
PBM_USERNAME = problem_user
PBM_PASSWORD = secret_sauce
PERFOR_USERNAME = performance_glitch_user
PERFOR_PASSWORD = secret_sauce
LOCKED_USERNAME = locked_out_user
LOCKED_PASSWORD = secret_sauce
